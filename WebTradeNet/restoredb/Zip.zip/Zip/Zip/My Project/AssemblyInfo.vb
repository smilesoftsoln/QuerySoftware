﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Zip Demo")> 
<Assembly: AssemblyDescription("Zip Demo Demonstrates zipping and unzipping files using the VB.Net 2008 ZipPackage Class")> 
<Assembly: AssemblyCompany("VisualBasicRocks.com")> 
<Assembly: AssemblyProduct("Zip Demo")> 
<Assembly: AssemblyCopyright("Copyright © 2008 VisualBasicRocks")> 
<Assembly: AssemblyTrademark("VisualBasicRocks.com")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("5c4ea278-d6cf-4e96-a1de-5f95d799e4aa")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
